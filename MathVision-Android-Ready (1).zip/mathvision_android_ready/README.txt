MATHVISION — INSTALLABLE ANDROID-FRIENDLY WEB APP

This package turns the existing MathVision website into a Progressive Web App (PWA).
It is not yet a Play Store APK. It can be installed from Chrome after you publish it
on an HTTPS website.

FILES
- index.html: complete MathVision app (Days 1–6)
- manifest.webmanifest: install name, colors, and icon settings
- service-worker.js: offline caching support
- icons/: app icons

HOW TO PUT IT ONLINE
1. Keep all files and the icons folder together; do not rename them.
2. Publish this folder to a static website host that provides HTTPS (for example,
   GitHub Pages or Netlify). Upload the folder contents, not just index.html.
3. Open the published HTTPS address in Chrome on Android.
4. Use Chrome's three-dot menu and choose "Install app" or "Add to Home screen"
   (the exact wording can vary).
5. Open MathVision from its new home-screen icon.

IMPORTANT
- Service workers and app installation generally require HTTPS (localhost is also
  supported for local development); opening index.html directly as file:// will not
  enable installation/offline support.
- Test the app on a real phone before sharing it widely.
- A PWA is a useful first release. Publishing a native APK or Play Store app is a
  separate next step.
